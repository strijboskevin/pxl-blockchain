/*
*  Copyright (c) Microsoft. All rights reserved. Licensed under the MIT license.
*  See LICENSE in the source repository root for complete license information.
*/

export const Configs = {
  appId: 'e6c987d2-8bdc-4f1a-bafc-04ba3d51f340',
  heroku: 'https://cors-anywhere.herokuapp.com/',
  scope: 'User.Read'
};
